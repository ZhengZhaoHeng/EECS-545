function output = sigmoid(x)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
output = 1./(1+exp(-x));

end